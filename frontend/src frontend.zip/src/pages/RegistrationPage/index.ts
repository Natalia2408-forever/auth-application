export * from './RegistrationPage';
